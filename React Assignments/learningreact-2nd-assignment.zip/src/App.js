import { Component } from "react";
import "./styles.css";
import "./ValidationComponent";
import ValidationComponent from "./ValidationComponent";
import CharComponent from "./CharComponent/CharComponent";

class App extends Component {
  state = {
    userInput: ""
  };

  deleted = (index) => {
    const textList = this.state.userInput.split("");
    textList.splice(index, 1);
    const updatedText = textList.join("");
    this.setState({
      userInput: updatedText
    });
  };

  changed = (event) => {
    this.setState({
      userInput: event.target.value
    });
  };

  render() {
    const charList = this.state.userInput.split("").map((ch, index) => {
      return (
        <CharComponent
          char={ch}
          key={index}
          clicked={() => this.deleted(index)}
        />
      );
    });

    return (
      <div className="App">
        <h1>Assignment 2</h1>
        <input
          rows="4"
          column="80"
          class="enterarea"
          type="text"
          onChange={this.changed}
          value={this.state.userInput}
        />
        <p>{this.state.userInput}</p>
        <ValidationComponent length={this.state.userInput.length} />
        {charList}
      </div>
    );
  }
}

export default App;
