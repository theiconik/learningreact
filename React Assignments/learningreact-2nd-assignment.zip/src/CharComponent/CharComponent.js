import React from "react";
import "./CCstyle.css";

const CharComponent = (props) => {
  return (
    <div className="ccc" onClick={props.clicked}>
      {props.char}
    </div>
  );
};
export default CharComponent;
