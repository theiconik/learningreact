import React from "react";

const UserInput = (props) => {
  const inputStyle = {
    border: "2px solid blue",
    borderRadius: "20px",
    width: "200px",
    height: "30px"
  };

  return (
    <div className="userinput">
      <input
        type="text"
        style={inputStyle}
        onChange={props.change}
        value={props.value}
      />
    </div>
  );
};

export default UserInput;
