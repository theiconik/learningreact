import React from "react";
import "./userOutput.css";

const UserOutput = (props) => {
  return (
    <div className="useroutput">
      <p>This is just a test text.</p>
      <p>{props.username}</p>
    </div>
  );
};

export default UserOutput;
